#!/usr/bin/env python
# coding: utf-8

# # Understanding the Data

# In[1]:


#Libraries Required are Imported here.

#For Data Handling and Analysis
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

#For Logistic Regression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix

#For K Nearest Neighbours
from sklearn.neighbors import KNeighborsClassifier


# In[2]:


os.chdir("Datasets")


# In[3]:


train = pd.read_csv("ServiceTrainData.csv")
test = pd.read_csv("ServiceTestData.csv")


# In[4]:


train.info()


# In[5]:


train.describe()


# Note: OilQual: Mean and Median are similar.<br>
#       EnginePerf: Mean and Median are similar.<br>
#       NormMileage: Mean and Median are similar.<br>
#       TyreWear: Mean and Median are similar.<br>
#       HVACwear: Mean and Median are similar.<br>
# <br>
# This indicates absence of outliers and a good distribution of data

# In[6]:


train_data = train.copy(deep = True)  #Making a deep copy
test_data = test.copy(deep = True)
x_train = train_data.drop(columns = ['Service'], axis = 1)  #Dropping the dependent variable from the dataset
y_train = train_data['Service'].values

x_test = test_data.drop(columns = ['Service'], axis = 1)
y_test = test_data['Service'].values


# In[7]:


x_train.isnull().sum() #No NULL Values detected
features = train_data.columns


# In[8]:


sns.pairplot(data = x_train)  #Visual analysis of plots suggest a clustering of data among 5 different clusters.


# In[9]:


corr_matrix = x_train.corr()
print(corr_matrix)


# Correlation Matrix Suggests:<br>
# A very high correlation between all 5 independent variables

# In[10]:


sns.heatmap(np.abs(corr_matrix), xticklabels = corr_matrix.columns, yticklabels = corr_matrix.columns)


# # Logistic Regression Approach for Classification

# In[11]:


logistic = LogisticRegression()
logistic.fit(x_train, y_train)
print(logistic.coef_, logistic.intercept_)


# In[12]:


y_pred = logistic.predict(x_test)


# In[13]:


conf_mat = confusion_matrix(y_test, y_pred)
print(conf_mat) 


# In[14]:


acc = accuracy_score(y_test, y_pred)
print("Accuracy: ",acc*100,"%")


# In[15]:


print('Misclassified Samples: %d' %(y_test != y_pred).sum())


# In[16]:


y_pred_df = pd.DataFrame(data = y_pred)
result_set = pd.DataFrame.join(x_test, y_pred_df)

res_csv_log = result_set.to_csv()

with open('result_log.csv', 'w') as res_csv_log:
    result_set.to_csv(path_or_buf= res_csv_log)


# # K - Nearest Neighbours for Classification

# In[17]:


knn = KNeighborsClassifier(n_neighbors = 5)


# In[18]:


knn.fit(x_train, y_train)
y_pred = knn.predict(x_test)


# In[19]:


conf_mat = confusion_matrix(y_test, y_pred)
print(conf_mat)


# In[20]:


acc = accuracy_score(y_test, y_pred)
print("Accuracy: ",acc*100,"%")


# In[21]:


print('Misclassified Samples: %d' %(y_test != y_pred).sum())


# In[22]:


y_pred_df = pd.DataFrame(data = y_pred)
result_set = pd.DataFrame.join(x_test, y_pred_df)

res_csv_knn = result_set.to_csv()

with open('result_knn.csv', 'w') as res_csv_knn:
    result_set.to_csv(path_or_buf= res_csv_knn)

